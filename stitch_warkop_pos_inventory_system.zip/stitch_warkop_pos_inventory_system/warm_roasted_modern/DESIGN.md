---
name: Warm Roasted Modern
colors:
  surface: '#fff8f5'
  surface-dim: '#e2d8d2'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fcf2eb'
  surface-container: '#f6ece5'
  surface-container-high: '#f1e6e0'
  surface-container-highest: '#ebe1da'
  on-surface: '#1f1b17'
  on-surface-variant: '#554336'
  inverse-surface: '#352f2b'
  inverse-on-surface: '#f9efe8'
  outline: '#887364'
  outline-variant: '#dbc2b0'
  surface-tint: '#904d00'
  primary: '#8d4b00'
  on-primary: '#ffffff'
  primary-container: '#b15f00'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb77d'
  secondary: '#5e5e65'
  on-secondary: '#ffffff'
  secondary-container: '#e4e1ea'
  on-secondary-container: '#64636b'
  tertiary: '#006c49'
  on-tertiary: '#ffffff'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcc3'
  primary-fixed-dim: '#ffb77d'
  on-primary-fixed: '#2f1500'
  on-primary-fixed-variant: '#6e3900'
  secondary-fixed: '#e4e1ea'
  secondary-fixed-dim: '#c8c5cd'
  on-secondary-fixed: '#1b1b21'
  on-secondary-fixed-variant: '#47464d'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#fff8f5'
  on-background: '#1f1b17'
  surface-variant: '#ebe1da'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  currency-display:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  currency-body:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies a grounded, efficient, and welcoming atmosphere tailored for Indonesian coffee shops and traditional *warkop* businesses scaling into modern point-of-sale and inventory management. It reconciles high-volume cashier workflow needs—where speed, error prevention, and legible monetary figures are critical—with the approachable warmth of Indonesian community café culture.

The visual style blends **Corporate / Modern** utilitarian precision with rich tactile warmth. Interfaces maintain high contrast for all lighting conditions found in street-side open spaces and indoor cafés. The experience evokes calm confidence, operational clarity, and grounded hospitality.

## Colors

The palette establishes an immediate hierarchy designed for quick visual parsing under rapid service conditions.

- **Primary Accent (`#D97706`)**: Warm honey amber provides intuitive visual focus for key interaction points, active states, checkout triggers, and highlights.
- **Structural Neutral & Dark Accent (`#1E1E24` and `#2A2521`)**: Deep roasted charcoal and rich dark tones anchor the primary typography, navigation drawers, and structural frames.
- **Success & Status (`#10B981`)**: Fresh emerald green handles affirmative states, completed transactions, healthy stock statuses, and cash totals.
- **Base Surfaces & Outlines**: Clean, soft warm creams (`#F9F8F6` to `#FFFFFF`) serve as canvas backgrounds to reduce glare, supported by crisp slate dividers (`#E2E8F0`).

Warning states utilize rich amber-orange (`#F59E0B`), while destructive alerts utilize a balanced crimson (`#EF4444`).

## Typography

Typography prioritizes functional legibility and tabular efficiency:

- **Headings**: Styled in **Plus Jakarta Sans** for a structured yet friendly and modern aesthetic across order sheets, drawer summaries, and category navigation.
- **Body & Controls**: Rendered in **Inter** to ensure maximum glyph neutrality and crispness across dense inventory tables, receipts, and order lines.
- **Numerical Treatment**: All prices in Indonesian Rupiah (Rp) and stock counts must enforce tabular lining numbers (`font-variant-numeric: tabular-nums; font-feature-settings: 'tnum' 1;`). This maintains vertical column alignment across itemized tables, checkout bills, and daily financial reconciliations.

## Layout & Spacing

The layout uses a multi-pane fixed and fluid model tailored to desktop and POS touch registers:

- **Structure**: A fixed compact sidebar navigation (64px–240px collapsable), a flexible catalog/inventory grid area, and a permanent or pinned split receipt tray (360px–420px fixed) for active cashier operations.
- **Rhythm**: All spatial padding, gutters, and layout gaps adhere strictly to an 8px base rhythm (`0.25rem`, `0.5rem`, `1rem`, `1.5rem`, `2rem`).
- **Touch Ergonomics**: All interactive POS targets (menu catalog buttons, modifier tiles, and primary checkout buttons) maintain a minimum hit target dimension of 44px (ideally 48px to 56px) with an inner spacing of at least `space-md` (16px).

## Elevation & Depth

Visual hierarchy combines **tonal layering** and **low-contrast outlines** with minimal, warm-tinted ambient shadows:

- **Flat Outlines**: Default UI containers, catalog items, and table rows are defined primarily through subtle slate outlines (`1px solid #E2E8F0`) over solid backgrounds (`#FFFFFF` on `#F9F8F6`).
- **Surface Elevation**: Active modal overlays, persistent sticky checkout bars, and dropdown popovers use subtle ambient shadows tinted with warm charcoal (`rgba(42, 37, 33, 0.08)` to `rgba(42, 37, 33, 0.12)`) to provide separation without visual clutter.
- **Depth Layers**:
  - `Level 0 (Canvas)`: `#F9F8F6` background.
  - `Level 1 (Card/Table Surface)`: Pure `#FFFFFF` surface with `1px solid #E2E8F0`.
  - `Level 2 (Popovers / Flyout Trays)`: `#FFFFFF` with `0 4px 16px -2px rgba(42, 37, 33, 0.08)`.
  - `Level 3 (Modal Confirmation)`: `#FFFFFF` with `0 12px 32px -4px rgba(42, 37, 33, 0.16)`.

## Shapes

With a roundedness index of `2` (standard base radius of `0.5rem` / `8px`):

- **Standard Elements**: Form inputs, standard buttons, order item rows, and inventory badges use `8px` (`rounded`).
- **Cards and Dialogs**: Product tiles, receipt panels, and modal dialogs use `16px` (`rounded-lg` / `1rem`) for approachable containment.
- **Category Chips and Status Pills**: Filter chips, quick-order badges, and stock state tags use continuous rounded pill treatments to instantly differentiate functional tags from rectangular action cards.

## Components

### Buttons
- **Primary Action (e.g., Bayar / Checkout)**: Honey Amber (`#D97706`) background, white text (`#FFFFFF`), `font-weight: 600`, minimum 48px height. Active states shift to a darker amber tone with subtle scale compression (`scale(0.98)`).
- **Secondary Action**: White surface (`#FFFFFF`) with `#E2E8F0` border and `#1E1E24` text.
- **Cashier Quick-Add Buttons**: Generous touch targets with clear text labels and tabular currency subtitles.

### Cards (Product & Inventory Grid)
- Clean white tile with a `1px solid #E2E8F0` border.
- 1:1 image or warm placeholder container on top, followed by `Plus Jakarta Sans` product title (`headline-sm`) and prominent Rupiah price (`currency-body` in `#1E1E24` or `#D97706`).
- Integrated stock pill badge indicating available portions or raw bean inventory levels.

### Chips & Badges
- **Status Pills**:
  - *Tersedia (In Stock)*: Soft green tint (`#ECFDF5`) background with emerald green (`#047857`) text.
  - *Menipis (Low Stock)*: Soft amber tint (`#FFFBEB`) background with amber-brown (`#B45309`) text.
  - *Habis (Out of Stock)*: Soft rose tint (`#FEF2F2`) background with dark red (`#B91C1C`) text.
- **Category Filter Chips**: Pill-shaped filters using `#FFFFFF` with `#E2E8F0` border; active category chips invert to `#1E1E24` fill with white text.

### Form Inputs & Numeric Keypads
- High-contrast text input borders (`#CBD5E1`) focusing to `#D97706` with a soft amber glow ring (`0 0 0 3px rgba(217, 119, 6, 0.2)`).
- Numerical calculator pad for custom cash tender displays large 20px tabular figures and tactile feedback borders.

### Tables (Inventory & Daily Journal)
- Minimalist headers with uppercase tracking (`label-md` in `#64748B`).
- Clean zebra alternation using `#FFFFFF` and `#FDFDFD`.
- Fixed right-aligned currency columns with strict tabular numeral alignment.